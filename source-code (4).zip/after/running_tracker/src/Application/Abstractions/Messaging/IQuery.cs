﻿namespace Application.Abstractions.Messaging;

public interface IQuery<TResponse>
{
}
