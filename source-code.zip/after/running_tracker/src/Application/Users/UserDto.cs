﻿namespace Application.Users;

public sealed record UserDto(Guid Id, string Name);
