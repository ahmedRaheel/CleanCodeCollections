﻿namespace Domain.Abstractions;

public interface IDomainEvent
{
}